Ext.define('AM.view.master.Category', {
    extend: 'AM.view.Worksheet',
    alias: 'widget.categoryProcess',
	 
		
		items : [
			{
				xtype : 'categorylist' ,
				flex : 1 
			} 
		]
});
