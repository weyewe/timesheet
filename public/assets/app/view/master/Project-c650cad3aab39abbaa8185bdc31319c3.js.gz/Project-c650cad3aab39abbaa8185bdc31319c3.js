Ext.define('AM.view.master.Project', {
    extend: 'AM.view.Worksheet',
    alias: 'widget.projectProcess',
	 
		
		items : [
			{
				xtype : 'projectlist' ,
				flex : 1 
			} 
		]
});
