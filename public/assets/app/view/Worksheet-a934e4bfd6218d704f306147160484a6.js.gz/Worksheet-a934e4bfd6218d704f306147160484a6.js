Ext.define('AM.view.Worksheet', {
    extend: 'Ext.Container' ,
		alias: 'widget.worksheet',
		layout : {
			type: 'fit'
		}
});
