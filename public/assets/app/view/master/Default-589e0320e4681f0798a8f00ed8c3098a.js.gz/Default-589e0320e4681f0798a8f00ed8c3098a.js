Ext.define('AM.view.master.Default', {
    extend: 'Ext.Container' ,
		alias: 'widget.masterDefault',
	 
		html : "Ini adalah tampilan master. Anda dapat membuat master baru, atau menambah customer"
});
