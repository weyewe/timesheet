Ext.define('AM.view.personal.Default', {
    extend: 'Ext.Container' ,
		alias: 'widget.personalDefault',
	 
		html : "Ini adalah tampilan personal. Anda dapat melihat sejarah kerja anda"
});
