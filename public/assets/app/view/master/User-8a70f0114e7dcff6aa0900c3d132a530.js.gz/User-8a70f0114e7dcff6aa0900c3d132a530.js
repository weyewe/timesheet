Ext.define('AM.view.master.User', {
    extend: 'AM.view.Worksheet',
    alias: 'widget.userProcess',
	 
		
		items : [
			{
				xtype : 'userlist' ,
				flex : 1 //,
				// html : 'hahaha'
			} 
		]
});
